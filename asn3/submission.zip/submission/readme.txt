gcc -o smallsh smallsh.c
